import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'awareness_page_model.dart';
export 'awareness_page_model.dart';

/// Create a new page called HealthAwarenessPage.
///
/// The page should be a clean, scrollable health awareness article.
///
/// Layout:
///
/// Scaffold
///
/// SafeArea
///
/// SingleChildScrollView
///
/// Column (crossAxisAlignment: start)
///
/// Horizontal padding: 16
///
/// Design multiple content sections using this reusable structure:
///
/// Section pattern:
///
/// Container
///
/// Padding: 16
///
/// Border radius: 16
///
/// Very light neutral background
///
/// Inside: Column (crossAxisAlignment: start)
///
/// Title Text (font size 20–24, bold, left aligned)
///
/// SizedBox (12 height)
///
/// Body Text (font size 15–16, line height 1.5, left aligned, supports
/// multiple paragraphs)
///
/// The first section (introduction) should not use a background container. It
/// should have:
///
/// Large main title (24–26, bold)
///
/// Body text below it
///
/// Add 24px vertical spacing between all sections.
///
/// At the bottom, include one separate centered Text widget for a final
/// emphasis sentence:
///
/// Font size 18–20
///
/// Medium weight
///
/// Center aligned
///
/// Extra top spacing (32px)
///
/// Add a button below with a name 'No name'. No action yet.
class AwarenessPageWidget extends StatefulWidget {
  const AwarenessPageWidget({super.key});

  static String routeName = 'Awareness_Page';
  static String routePath = '/awarenessPage';

  @override
  State<AwarenessPageWidget> createState() => _AwarenessPageWidgetState();
}

class _AwarenessPageWidgetState extends State<AwarenessPageWidget> {
  late AwarenessPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AwarenessPageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Understanding Your Health',
                        textAlign: TextAlign.start,
                        style:
                            FlutterFlowTheme.of(context).headlineLarge.override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineLarge
                                        .fontStyle,
                                  ),
                                  fontSize: 26.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineLarge
                                      .fontStyle,
                                ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                        child: Text(
                          'Obesity…  invisible, yet one of the leading causes of death worldwide.\n\nIt silently affects millions of people, increasing the risk of heart disease, diabetes, high blood pressure, and other life-threatening conditions — often without clear warning signs.\n\nMany underestimate its impact until it begins to affect their daily life, energy levels, and long-term health. But the earlier you become aware, the more control you have.\n\nUnderstand your body, check your BMI, and get personalized guidance to start building a healthier future — one step at a time.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                    lineHeight: 1.5,
                                  ),
                        ),
                      ),
                    ],
                  ),
                  Text(
                    'It’s never too late to improve your health.\nStart small. Stay consistent.',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).titleLarge.override(
                          font: GoogleFonts.interTight(
                            fontWeight: FontWeight.w500,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontStyle,
                          ),
                          fontSize: 20.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w500,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleLarge.fontStyle,
                        ),
                  ),
                  FFButtonWidget(
                    onPressed: () async {
                      context.pushNamed(AIInputPageWidget.routeName);
                    },
                    text: 'Let\'s calculate your BMI',
                    options: FFButtonOptions(
                      width: double.infinity,
                      height: 48.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: Color(0xFF2797FF),
                      textStyle:
                          FlutterFlowTheme.of(context).titleMedium.override(
                                font: GoogleFonts.interTight(
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .fontStyle,
                                ),
                                color: Colors.white,
                                letterSpacing: 0.0,
                                fontWeight: FlutterFlowTheme.of(context)
                                    .titleMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .titleMedium
                                    .fontStyle,
                              ),
                      elevation: 0.0,
                      borderSide: BorderSide(
                        color: Colors.transparent,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                  ),
                ].divide(SizedBox(height: 24.0)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
