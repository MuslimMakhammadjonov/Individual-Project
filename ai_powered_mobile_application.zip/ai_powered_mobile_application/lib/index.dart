// Export pages
export '/welcome_page/welcome_page_widget.dart' show WelcomePageWidget;
export '/a_i_input_page/a_i_input_page_widget.dart' show AIInputPageWidget;
export '/a_i_result_page/a_i_result_page_widget.dart' show AIResultPageWidget;
export '/onboarding_2/onboarding2_widget.dart' show Onboarding2Widget;
export '/onboarding_3/onboarding3_widget.dart' show Onboarding3Widget;
export '/b_m_i_result_page/b_m_i_result_page_widget.dart'
    show BMIResultPageWidget;
export '/onboarding_1/onboarding1_widget.dart' show Onboarding1Widget;
export '/awareness_page/awareness_page_widget.dart' show AwarenessPageWidget;
