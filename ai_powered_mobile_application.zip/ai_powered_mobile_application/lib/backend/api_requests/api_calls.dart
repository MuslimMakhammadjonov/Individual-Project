import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class NewAPICallCall {
  static Future<ApiCallResponse> call({
    double? bmiResult,
    String? bmiStatus = '',
    double? age,
    String? gender = '',
    String? apiKey =
        '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',
    String? goal = '',
    String? model = 'gpt-4o-mini',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o-mini",
  "messages": [
    {
      "role": "user",
      "content": "Hey — I’m glad you’re taking a positive step toward improving your health!\\n\\nUser profile:\\nAge: ${age}\\nGender: ${escapeStringForJson(gender)}\\nBMI score: ${bmiResult}\\nBMI status: ${escapeStringForJson(bmiStatus)}\\nPrimary goal: ${escapeStringForJson(goal)}\\n\\nCreate a personalized health plan based ONLY on this user’s data.\\n\\nInstructions:\\n1. Briefly explain what the user's BMI status means.\\n2. Tailor advice to BOTH BMI status and goal.\\n3. Include:\\n- Exercise recommendations (safe and beginner-friendly)\\n- Nutrition guidance (practical, balanced)\\n- Daily habits (sleep, hydration, walking)\\n4. Adjust tone by BMI category.\\n5. Adapt suggestions for age and gender.\\n6. Avoid generic advice.\\n7. Be motivating but realistic.\\n8. Do NOT give medical diagnoses.\\n\\nFormat sections:\\nBMI Summary\\nExercise Plan\\nNutrition Tips\\nDaily Habits\\nMotivation\\n\\nEnd with:\\nIf you have any medical conditions or chronic illnesses, please consult a qualified healthcare professional before making major lifestyle changes."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NewAPICall',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
