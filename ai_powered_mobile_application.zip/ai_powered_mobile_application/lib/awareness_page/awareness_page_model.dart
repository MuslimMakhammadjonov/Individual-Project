import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'awareness_page_widget.dart' show AwarenessPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AwarenessPageModel extends FlutterFlowModel<AwarenessPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
