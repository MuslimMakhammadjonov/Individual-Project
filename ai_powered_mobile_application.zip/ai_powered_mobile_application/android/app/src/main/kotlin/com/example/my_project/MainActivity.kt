package com.mycompany.aipoweredmobileapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
