import 'package:flutter/material.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  double _weight = 0.0;
  double get weight => _weight;
  set weight(double value) {
    _weight = value;
  }

  int _age = 0;
  int get age => _age;
  set age(int value) {
    _age = value;
  }

  String _gender = '';
  String get gender => _gender;
  set gender(String value) {
    _gender = value;
  }

  double _bmiResult = 0.0;
  double get bmiResult => _bmiResult;
  set bmiResult(double value) {
    _bmiResult = value;
  }

  double _height = 0.0;
  double get height => _height;
  set height(double value) {
    _height = value;
  }

  String _bmiStatus = '';
  String get bmiStatus => _bmiStatus;
  set bmiStatus(String value) {
    _bmiStatus = value;
  }

  String _goal = '';
  String get goal => _goal;
  set goal(String value) {
    _goal = value;
  }

  String _bmiMessage = '';
  String get bmiMessage => _bmiMessage;
  set bmiMessage(String value) {
    _bmiMessage = value;
  }

  String _aiResult = '';
  String get aiResult => _aiResult;
  set aiResult(String value) {
    _aiResult = value;
  }
}
