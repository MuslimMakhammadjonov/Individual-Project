import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/index.dart';
import 'a_i_result_page_widget.dart' show AIResultPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AIResultPageModel extends FlutterFlowModel<AIResultPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
