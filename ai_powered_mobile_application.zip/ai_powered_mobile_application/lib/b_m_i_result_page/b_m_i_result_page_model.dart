import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'b_m_i_result_page_widget.dart' show BMIResultPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BMIResultPageModel extends FlutterFlowModel<BMIResultPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (NewAPICall)] action in Button widget.
  ApiCallResponse? aiResult;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
